var config = {
	"map": {
	    "*": {
	    	
	    	"bannerslider": "js/jquery.bxslider",

	    }
	},
	paths: {
		'mageants/bannerslider': 'Mageants_BannerSlider/js/jquery.bxslider'
	},
	shim: {    
	}
};
